//
//  AppDelegate.swift
//  MyLocations
//
//  Created by Adnan Brohi on 21/05/2022.
//

import UIKit
import CoreData

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    lazy var presistentContainer:NSPersistentContainer = {
       let container = NSPersistentContainer(name: "DataModel")
        container.loadPersistentStores (completionHandler: { storeDescription, error in
            if let error = error {
                fatalError("could not load data store\(error)")
            }
            
        })
        return container
    }()
    
    lazy var managedObjectContext : NSManagedObjectContext = presistentContainer.viewContext

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        customizeApparance()
        let tabController = window!.rootViewController as! UITabBarController
        if let tabViewControllers = tabController.viewControllers {
          // first Tab
        var navController = tabViewControllers[0] as! UINavigationController
        let controller1 = navController.viewControllers.first as! CurrentlocationViewController
        controller1.managedObjectContext = managedObjectContext
        // second tab
        navController = tabViewControllers[1] as! UINavigationController
        let controller2 = navController.viewControllers.first as! LocationsViewController
            controller2.managedObjectContext = managedObjectContext
         // third tab
         navController = tabViewControllers[2] as! UINavigationController
        let controller3 = navController.viewControllers.first as! MapViewController
            controller3.managedObjectContext = managedObjectContext
            //to avoid core data error
            let _ = controller2.view
            
        }
        print("Directory")
        print(applicationDocumentDirectory)
        listenForFatalErrorCoreDataNotifications()
        // Override point for customization after application launch.
        return true
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }
    
    func customizeApparance() {
        UINavigationBar.appearance().barTintColor = UIColor.black
        UINavigationBar.appearance().titleTextAttributes = [NSAttributedString.Key.foregroundColor:UIColor.white]
        UITabBar.appearance().barTintColor = UIColor.black
        let tintColor = UIColor(red: 255/255.0, green: 238/255.0, blue: 136/255.0, alpha: 1.0)
        UITabBar.appearance().tintColor = tintColor
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }
    
    func listenForFatalErrorCoreDataNotifications(){
        NotificationCenter.default.addObserver(forName: CoreDataSaveFailedNotification, object: nil, queue: OperationQueue.main, using: {
            Notification in
            
            let message = """
            there was a fatal errorin the app and it continue.
            press OK  to terminate the app. sorry for the inconvenience.
            """
            let alert = UIAlertController(title: "Internal Error", message: message, preferredStyle: .alert)
            let action = UIAlertAction(title: "OK", style: .default) {_ in
                let exception = NSException(name: NSExceptionName.internalInconsistencyException, reason: "Fatal Core Data Error", userInfo: nil)
                exception.raise()
                
            }
            alert.addAction(action)
            let tabController = self.window!.rootViewController!
            tabController.present(alert, animated: true, completion: nil)
                                       

        })
    }
}

