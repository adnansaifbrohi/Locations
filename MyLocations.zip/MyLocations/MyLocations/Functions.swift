//
//  Functions.swift
//  MyLocations
//
//  Created by Adnan Brohi on 06/06/2022.
//

import Foundation

func afterDelay(_ seconds: Double, run:@escaping () -> Void){
    DispatchQueue.main.asyncAfter(deadline: .now() + seconds, execute: run)
}
let applicationDocumentDirectory: URL = {
    let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
    return paths[0]
}()

let CoreDataSaveFailedNotification = Notification.Name(rawValue: "CoreDataSaveFailedNotification")

func fatalCoreDateError(_ error: Error){
    print("*** Fatal Error:\(error)")
    NotificationCenter.default.post(name: CoreDataSaveFailedNotification, object: nil)
}
