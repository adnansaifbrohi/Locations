//
//  MyImagePickerController.swift
//  MyLocations
//
//  Created by Adnan Brohi on 17/06/2022.
//

import Foundation
import UIKit

class myImagePickerController: UIImagePickerController {
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
}
