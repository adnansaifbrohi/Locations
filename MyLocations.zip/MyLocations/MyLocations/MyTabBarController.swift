//
//  MyTabBarController.swift
//  MyLocations
//
//  Created by Adnan Brohi on 17/06/2022.
//

import Foundation
import UIKit

class MyTabBarController: UITabBarController {
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    override var childForStatusBarStyle: UIViewController? {
        return nil
    }
}
