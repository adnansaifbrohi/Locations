//
//  String+AddText.swift
//  MyLocations
//
//  Created by Adnan Brohi on 17/06/2022.
//

import Foundation

extension String {
    mutating func add(text: String?,separatedBy separtor: String = ""){
        if let text = text {
            if !isEmpty {
                self += separtor
            }
            self += text
        }
    }
}
